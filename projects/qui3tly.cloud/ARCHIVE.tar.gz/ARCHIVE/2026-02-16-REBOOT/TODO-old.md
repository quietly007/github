# TODO - qui3tly.cloud

**Updated:** 2026-02-15  
**Current Phase:** Phase 01 — Infrastructure Stability  
**Phases Complete:** 1/9

---

## Phase 00: Foundation — DONE

Completed 2026-02-15. Baseline captured, 64 containers documented, 19 diagrams created, multi-agent verification complete. See [PHASE-00-FOUNDATION/](PHASE-00-FOUNDATION/).

---

## Phase 01: Infrastructure Stability — NEXT

**Goal:** Fix all critical issues found in Phase 00. Zero blocking errors.

### Critical (P0) — Must Fix First

| Task | Server | Problem | Status |
|------|--------|---------|--------|
| Fix UISP restart loop | Lady | `Makefile:22 Error 1` recurring, ~8/10min | TODO |
| Fix Odoo DB connection | Lady | Workers crash on startup, DB connection refused | TODO |
| Fix Blackbox mail.quietly.online | Master | Probe returns 403 (should be 200) | TODO |
| Fix Blackbox quietly.its.me | Master | Probe returns 401 (expected, but noisy) | TODO |

### High Priority (P1) — Should Fix

| Task | Server | Problem | Status |
|------|--------|---------|--------|
| CrowdSec SQLite WAL mode | Both | Performance optimization for DB writes | TODO |
| CrowdSec Traefik log parser | Both | Security log parsing broken | TODO |
| Grafana xychart plugin duplicate | Master | Plugin already registered warning | TODO |
| cAdvisor overlay2 access | Both | Cannot stat overlay filesystem | TODO |
| Unbound DNS healthcheck | Lady | DNS ping to 9.9.9.9 intermittently fails | TODO |

### Documentation (P2) — Create Runbooks

| Task | Status |
|------|--------|
| UISP troubleshooting runbook | TODO |
| Odoo troubleshooting runbook | TODO |
| Blackbox probe configuration guide | TODO |
| CrowdSec optimization guide | TODO |

### Phase Completion

| Task | Status |
|------|--------|
| All P0 tasks resolved | TODO |
| All P1 tasks resolved | TODO |
| All P2 runbooks created | TODO |
| Error logs clean (0 blocking) | TODO |
| Agent verification complete | TODO |
| User approval | TODO |

---

## Phase 02-09: Blocked

| Phase | Name | Blocked By | Key Tasks |
|-------|------|------------|-----------|
| 02 | Documentation Consolidation | P01 | Consolidate 452 files, fix contradictions, service catalog |
| 03 | Service Deployment | P01 | Office suite (OnlyOffice/Collabora), accounting (Odoo config) |
| 04 | Monitoring Validation | P01 | Validate 8 Grafana dashboards, test alerts |
| 05 | Backup & DR Verification | P01 | Test 3 DR methods, verify RTO targets |
| 06 | Security Hardening | P01 | Lady fail2ban jails, port scans, secrets audit |
| 07 | Branding Assets | P00 | Logo (5 variants), favicon set, brand deployment |
| 08 | Technical Excellence | P01-07 | Performance tuning, simplification, A+++ push |
| 09 | Documentation & Closure | P08 | Final docs, retrospective, certification |

---

## Out of Scope

- IPv6 deployment
- CCTV/NVR deployment (Frigate container exists, full deployment future)
- Mobile apps
- Montefish customer deployment
- Additional servers (Beauty, Madam)
- Multi-site VPN (Office, Parents)
- OSPF/FRR (permanently rejected)
