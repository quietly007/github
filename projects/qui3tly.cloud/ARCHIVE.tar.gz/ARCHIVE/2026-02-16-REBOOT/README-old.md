# qui3tly.cloud - Infrastructure Project

**Current Phase:** Phase 01 — Infrastructure Stability  
**Target Grade:** 90/100 (A+++)  
**Infrastructure:** 72/100 (C+) — 64 containers, 2 servers, all operational

---

## Project Status

| Phase | Name | Status |
|-------|------|--------|
| **00** | Foundation | **DONE** — baseline captured, plan created |
| **01** | Infrastructure Stability | **NEXT** — fix critical issues |
| 02 | Documentation Consolidation | Blocked by P01 |
| 03 | Service Deployment | Blocked by P01 |
| 04 | Monitoring Validation | Blocked by P01 |
| 05 | Backup & DR Verification | Blocked by P01 |
| 06 | Security Hardening | Blocked by P01 |
| 07 | Branding Assets | Blocked by P00 |
| 08 | Technical Excellence | Blocked by P01-07 |
| 09 | Documentation & Closure | Blocked by P08 |

---

## Infrastructure

| Server | IP | Tailscale | Containers | Role |
|--------|---|-----------|------------|------|
| Master | 213.136.68.108 | 100.64.0.1 | 25 | Control plane (Traefik, Headscale, monitoring, security) |
| Lady | 207.180.251.111 | 100.64.0.2 | 39 | Worker (Mailcow, Nextcloud, Odoo, UniFi, UISP) |

**Constraints:**
- Headscale = NATIVE systemd (not Docker)
- No OSPF/FRR (removed Jan 13, 2026)
- DNS bootstrap = immutable resolv.conf → 1.1.1.1
- Postfix = only MTA

---

## Key Documents

| Document | Purpose |
|----------|---------|
| [TODO.md](TODO.md) | Task tracker, current priorities |
| [MASTER_PLAN.md](MASTER_PLAN.md) | Strategy, timeline, phases |
| [RFP.md](RFP.md) | Full requirements |
| [AGENT_WORKFLOW.md](AGENT_WORKFLOW.md) | Multi-agent verification protocol |
| [PHASE-00-FOUNDATION/](PHASE-00-FOUNDATION/) | Completed foundation work |

---

## Phase 01: What Needs Fixing

**Critical (P0):**
- UISP restart loop / Makefile errors
- Odoo database connection failures at startup
- Blackbox probe failures (mail.quietly.online 403, quietly.its.me 401)

**High (P1):**
- CrowdSec SQLite WAL mode + Traefik log parser
- Grafana duplicate xychart plugin
- cAdvisor overlay2 filesystem access
- Unbound DNS healthcheck failures

**Docs (P2):**
- Troubleshooting runbooks for UISP, Odoo, Blackbox, CrowdSec

---

**Principle:** MAXIMALLY SIMPLIFIED — no bloat, evidence-based, check the system first.
