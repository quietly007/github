# PLAN — qui3tly.cloud

> **Approach**: Baseline → Gap Analysis → Fix → Verify → Document  
> **Rule**: Don't document broken things. Fix first, document after.  
> **Scope**: Everything in [BASELINE/](BASELINE/) is verified fact. This plan closes the gaps.

---

## Current State

64 containers, all running. Infrastructure works. But:

### Known Issues (from baseline audit 2026-02-15)

| # | Issue | Server | Severity | Impact |
|---|-------|--------|----------|--------|
| 1 | UISP restart loop (`Makefile:22 Error 1`) | Lady | Critical | Container restarts every ~8-10 min, log noise |
| 2 | Odoo DB connection refused | Lady | Critical | Workers crash on startup, service degraded |
| 3 | Blackbox probe `mail.quietly.online` → 403 | Master | Medium | False alert, should return 200 |
| 4 | Blackbox probe `quietly.its.me` → 401 | Master | Low | Expected (Authelia), but noisy in monitoring |
| 5 | CrowdSec SQLite WAL mode not enabled | Both | Medium | Suboptimal DB write performance |
| 6 | CrowdSec Traefik log parser broken | Both | Medium | Security logs not being parsed |
| 7 | cAdvisor cannot stat overlay2 filesystem | Both | Low | Missing container filesystem metrics |
| 8 | Unbound DNS healthcheck intermittent | Lady | Low | Occasional DNS ping failure to 9.9.9.9 |
| 9 | cAdvisor at 155% CPU | Lady | Medium | Resource waste |
| 10 | fail2ban incomplete on Lady | Lady | Medium | Missing traefik-auth + recidive jails |
| 11 | Services documented: 6/54 (11%) | Both | High | Can't hand off, can't onboard |
| 12 | Documentation scattered across 452 files, 5 locations | Both | High | No single source of truth |

### What Works (don't touch)

- Tailscale mesh VPN (Master ↔ Lady ↔ Mac)
- WireGuard P2P tunnel (Master ↔ Office EdgeRouter)
- Split-horizon DNS (Pi-hole → cloudflared → DoH)
- Traefik routing + TLS termination (both servers)
- Mailcow full stack (Postfix, Dovecot, Rspamd, SOGo, unbound)
- Nextcloud + OnlyOffice integration
- Monitoring pipeline (Prometheus → Grafana, Promtail → Loki)
- Authelia 2FA on sensitive services
- CrowdSec bouncer on Traefik (both servers)
- All 17 TLS certificates valid (Let's Encrypt DNS-01)

---

## Execution Order

Work is ordered by dependency. Can't verify monitoring if containers are broken. Can't document a service that's crashing. Can't test DR if security is loose.

### 1. FIX BROKEN THINGS

Fix issues #1-9 from the table above. No new features, no refactoring — just make everything healthy.

**Tasks:**
- [ ] Investigate & fix UISP restart loop (Makefile error)
- [ ] Investigate & fix Odoo DB connection (workers crashing)
- [ ] Fix Blackbox probe targets (correct expected status codes)
- [ ] Enable CrowdSec WAL mode on both servers
- [ ] Fix CrowdSec Traefik log acquisition on both servers
- [ ] Fix cAdvisor overlay2 access issue
- [ ] Fix cAdvisor CPU usage on Lady (155% is wrong)
- [ ] Investigate Unbound DNS healthcheck failures

**Verification:**
```bash
# After fixes — all containers healthy, zero error log lines
docker ps --format '{{.Names}}\t{{.Status}}' | grep -v "Up"     # should be empty
docker logs <container> 2>&1 | grep -i error | tail -5           # should be clean
```

**Depends on:** Nothing  
**Blocks:** Everything else

---

### 2. HARDEN SECURITY

Close security gaps while infrastructure is stable.

**Tasks:**
- [ ] Add fail2ban jails on Lady: `traefik-auth`, `recidive`
- [ ] Verify all secrets in `~/.secrets/` with 600 permissions, not in Git
- [ ] External port scan (both servers) — only 80, 443, SSH (key-only)
- [ ] Verify Authelia 2FA on all VPN-only services
- [ ] Update CrowdSec to latest community rules
- [ ] Verify Traefik `vpn-only` middleware blocks correctly (test from non-VPN IP)

**Verification:**
```bash
# fail2ban jails active
fail2ban-client status
# Secrets permissions
find ~/.secrets/ -type f ! -perm 600
# External port scan
nmap -sT -p- <server-ip> --open
```

**Depends on:** #1 (stable infrastructure)  
**Blocks:** #5 (DR test needs secure baseline)

---

### 3. VALIDATE MONITORING

Confirm every dashboard shows real data, every alert fires correctly.

**Tasks:**
- [ ] Walk through each Grafana dashboard — verify data populates
- [ ] Trigger a test alert → verify Alertmanager → Gotify delivery
- [ ] Verify Uptime Kuma has checks for ALL public services
- [ ] Eliminate false positives (Blackbox, cAdvisor warnings)
- [ ] Verify Loki receives logs from ALL containers (both servers)
- [ ] Confirm Prometheus scrape targets all UP

**Verification:**
```
Prometheus targets page: 0 targets DOWN
Grafana dashboards: all panels show data (no "No data" panels)
Alertmanager: test alert delivered to Gotify within 60s
```

**Depends on:** #1 (can't validate monitoring of broken containers)  
**Blocks:** #6 (need monitoring to verify final state)

---

### 4. DOCUMENT SERVICES

Single source of truth. Every service gets a runbook. Not a novel — a runbook.

**Per service, document exactly:**
1. What it does (1 sentence)
2. Where it runs (server, container name, network, port)
3. How to access it (URL, credentials location)
4. How to restart it (`docker restart <name>`)
5. How to check if it's healthy (command or URL)
6. What depends on it (upstream/downstream)
7. Known issues (if any)

**Tasks:**
- [ ] Create `RUNBOOKS/` directory
- [ ] Write runbook for each of the 54 unique services
- [ ] Consolidate scattered docs → single location
- [ ] Archive redundant files (322 backups identified)
- [ ] Verify zero contradictions across all docs

**Depends on:** #1 (don't document broken things)  
**Blocks:** #6 (DR needs procedures documented)

---

### 5. TEST DISASTER RECOVERY

Test all DR methods. Measure actual RTO. Document results.

**DR Methods to test:**
1. **Docker stack redeploy**: `docker compose up -d` after config change (target: 2 min)
2. **Ansible full restore**: Playbook rebuilds server from scratch (target: 15 min)
3. **Complete server rebuild**: New VPS + Ansible + restore data (target: 45 min)

**Tasks:**
- [ ] Test Method 1 on a non-critical service (restart + verify)
- [ ] Test Method 2 on a test environment (or secondary service)
- [ ] Verify backup locations (GitHub repos, Contabo snapshots)
- [ ] Verify backup freshness (last snapshot date)
- [ ] Document actual measured RTO for each method
- [ ] Create DR runbook with step-by-step procedures

**Depends on:** #2 (secure baseline), #4 (procedures documented)  
**Blocks:** #6

---

### 6. FINAL VERIFICATION

Everything fixed, secured, monitored, documented, DR-tested. Verify end state.

**Tasks:**
- [ ] Full container health check (64/64 healthy)
- [ ] Full service endpoint test (all return expected status)
- [ ] Error log review (zero critical/error lines)
- [ ] Security posture check (port scan, secrets, fail2ban)
- [ ] Monitoring coverage check (all targets, all dashboards)
- [ ] Documentation completeness check (54/54 services)
- [ ] DR readiness check (procedures tested, backups verified)
- [ ] Update BASELINE/ with final verified state

**Depends on:** #1-5 all complete  
**Blocks:** Nothing — this IS the finish line

---

## Out of Scope

Not now. Not this project. Maybe later.

- IPv6 deployment
- CCTV/NVR full deployment (Frigate container exists, config deferred)
- Mobile applications
- Montefish customer deployment
- Additional servers (Beauty, Madam)
- Multi-site VPN expansion (Office, Parents)
- OSPF/FRR (permanently rejected)
- Branding/logo assets (nice-to-have, not infrastructure)

---

## Dependencies — Visual

```
┌──────────────────────────┐
│  1. FIX BROKEN THINGS    │
│  (UISP, Odoo, Blackbox, │
│   CrowdSec, cAdvisor)    │
└─────────┬────────────────┘
          │
          ├──────────────────────────────────┐
          │                                  │
          ▼                                  ▼
┌─────────────────────┐          ┌───────────────────────┐
│  2. HARDEN SECURITY │          │  3. VALIDATE          │
│  (fail2ban, secrets, │          │     MONITORING        │
│   port scan, 2FA)    │          │  (dashboards, alerts, │
│                      │          │   Loki, Uptime Kuma)  │
└─────────┬────────────┘          └───────────┬───────────┘
          │                                   │
          ▼                                   │
┌─────────────────────┐                       │
│  4. DOCUMENT         │                       │
│     SERVICES         │                       │
│  (54 runbooks,       │                       │
│   consolidation)     │                       │
└─────────┬────────────┘                       │
          │                                    │
          ▼                                    │
┌─────────────────────┐                        │
│  5. TEST DR          │                        │
│  (3 methods,         │                        │
│   measure RTO)       │                        │
└─────────┬────────────┘                        │
          │                                     │
          ▼                                     ▼
┌──────────────────────────────────────────────────┐
│  6. FINAL VERIFICATION                           │
│  (all green, all documented, all tested)         │
└──────────────────────────────────────────────────┘
```

**Critical path**: 1 → 2 → 4 → 5 → 6  
**Parallel**: 2 + 3 can run simultaneously after 1
